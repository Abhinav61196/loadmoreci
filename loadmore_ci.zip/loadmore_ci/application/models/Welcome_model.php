<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome_model extends CI_Model{

    public function getCountry($page){
        $offset = 100*$page;
        $limit = 100;
        $sql = "select * from load_more_countries limit $offset ,$limit";
        $result = $this->db->query($sql)->result();
        return $result;
    }
}